set( "sim/private/controls/lights/exponent_far", 0.52)
set( "sim/private/controls/lights/exponent_near", 0.52)

set( "sim/private/controls/lights/bloom_far", 1500)
set( "sim/private/controls/lights/dist_far", 1000)
set( "sim/private/controls/lights/dist_near", 100)
set( "sim/private/controls/lights/scale_far", 0.5)
set( "sim/private/controls/lights/scale_near", 0.5)
set( "sim/private/controls/lights/spill_scale", 166.0)

set( "sim/private/controls/lights/always_night_lights", 1)
